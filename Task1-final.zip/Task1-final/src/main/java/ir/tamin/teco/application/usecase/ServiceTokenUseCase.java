package ir.tamin.teco.application.usecase;

import ir.tamin.teco.application.result.ServiceTokenResult;

public interface ServiceTokenUseCase {

    ServiceTokenResult handle();
}
