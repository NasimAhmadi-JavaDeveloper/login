package ir.tamin.teco.infrastructure.config;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

@Configuration
public class CacheConfig {

    private static final int SECONDS_1_MIN = 60;//TODO
    private static final int SECONDS_2_MIN = 120;//TODO

    @Bean
    public CacheManager cacheManager() {
        CaffeineCacheManager cacheManager = new CaffeineCacheManager();

        cacheManager.registerCustomCache("config",
                buildCache(SECONDS_1_MIN));

        cacheManager.registerCustomCache("optimusServiceToken",
                buildCache(SECONDS_2_MIN));

        return cacheManager;
    }

    private Cache<Object, Object> buildCache(int ttlSeconds) {
        return Caffeine.newBuilder()
                .expireAfterWrite(ttlSeconds, TimeUnit.SECONDS)
                .maximumSize(10_000)
                .recordStats()
                .build();
    }
}
