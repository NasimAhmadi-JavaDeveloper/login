package ir.tamin.teco.application.service;

import ir.tamin.teco.application.port.out.OptimusOut;
import ir.tamin.teco.application.result.ServiceTokenResult;
import ir.tamin.teco.domain.service.ServiceToken;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LoginOptimusServiceImpl implements ServiceToken {

    private final OptimusOut optimusOut;

    @Override
    public ServiceTokenResult login() {
        return new ServiceTokenResult(optimusOut.getServiceToken());
    }
}
