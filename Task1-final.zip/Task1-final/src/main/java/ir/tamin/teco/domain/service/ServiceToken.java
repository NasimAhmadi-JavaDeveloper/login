package ir.tamin.teco.domain.service;

import ir.tamin.teco.application.result.ServiceTokenResult;

public interface ServiceToken {

    ServiceTokenResult login();

}