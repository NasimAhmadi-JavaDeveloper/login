package ir.tamin.teco.application.handler;


import ir.tamin.teco.application.result.ServiceTokenResult;
import ir.tamin.teco.application.usecase.ServiceTokenUseCase;
import ir.tamin.teco.domain.service.ServiceToken;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ServiceTokenHandler implements ServiceTokenUseCase {

    private final ServiceToken serviceToken;

    @Override
    public ServiceTokenResult handle() {
        return serviceToken.login();
    }
}
