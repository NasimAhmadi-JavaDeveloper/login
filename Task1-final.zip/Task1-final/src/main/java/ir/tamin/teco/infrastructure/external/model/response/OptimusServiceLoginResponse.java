package ir.tamin.teco.infrastructure.external.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

public record OptimusServiceLoginResponse(@JsonProperty("tracking_code") String trackingCode, Result result) {

    @Getter
    @Setter
    public static class Result {
        private String token;
        private User user;
        private Integer expireIn;
    }

    @Getter
    @Setter
    public static class User {
        private String username;
        private Integer tenantId;
        private Integer id;
        private String role;
        private Integer application;
    }
}