package ir.tamin.teco.domain.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@RequiredArgsConstructor
public enum ExceptionSpec {

    CONFIG_NOT_FOUND("Configuration not found: %s", HttpStatus.NOT_FOUND),
    OPTIMUS_EMPTY_RESPONSE("Optimus returned empty response", HttpStatus.BAD_GATEWAY),
    OPTIMUS_AUTH_FAILED("Optimus authentication failed. HTTP status: %s", HttpStatus.BAD_GATEWAY),
    OPTIMUS_TOKEN_MISSING("Optimus token is missing in response", HttpStatus.BAD_GATEWAY),


    ;
    private final String message;
    private final HttpStatus httpStatus;

    public String format(Object... args) {
        return String.format(message, args);
    }
}