package ir.tamin.teco.domain.enums;

public enum ConfigKey {
    UPTIMOUS_BASE_URL,
    UPTIMOUS_AUTH_URL,
    UPTIMOUS_USERNAME,
    UPTIMOUS_PASSWORD,
    UPTIMOUS_APP_KEY,
    UPTIMOUS_SERVICE_NAME
}