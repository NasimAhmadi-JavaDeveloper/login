package ir.tamin.teco.domain.exception;

import ir.tamin.teco.domain.enums.ConfigKey;
import ir.tamin.teco.domain.enums.ExceptionSpec;
import lombok.Getter;

@Getter
public class ConfigurationNotFoundException extends RuntimeException {

    private final ExceptionSpec spec;
    private final ConfigKey key;

    public ConfigurationNotFoundException(ExceptionSpec spec, ConfigKey key) {
        super(spec.format(key));
        this.spec = spec;
        this.key = key;
    }
}
