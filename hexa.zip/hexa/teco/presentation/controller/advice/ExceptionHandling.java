package ir.tamin.teco.presentation.controller.advice;

import ir.tamin.teco.domain.exception.ConfigurationNotFoundException;
import ir.tamin.teco.presentation.model.response.ErrorResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ExceptionHandling extends ResponseEntityExceptionHandler {

    //TODO WE NEED APP-LOGGER HERE

    @ExceptionHandler(ConfigurationNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleConfigurationNotFound(ConfigurationNotFoundException ex) {

        var spec = ex.getSpec();

        ErrorResponse response = new ErrorResponse(ex.getMessage());

        return ResponseEntity
                .status(spec.getHttpStatus())
                .body(response);
    }
}
