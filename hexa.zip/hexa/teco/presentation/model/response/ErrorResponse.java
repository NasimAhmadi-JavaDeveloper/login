package ir.tamin.teco.presentation.model.response;

public record ErrorResponse(String message) {

}
