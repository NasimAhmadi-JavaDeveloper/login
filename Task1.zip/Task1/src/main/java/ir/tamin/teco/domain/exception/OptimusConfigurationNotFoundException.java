package ir.tamin.teco.domain.exception;

public class OptimusConfigurationNotFoundException extends RuntimeException {
    public OptimusConfigurationNotFoundException(String message) {
        super(message);
    }
}
