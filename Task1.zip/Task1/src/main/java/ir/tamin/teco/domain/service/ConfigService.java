package ir.tamin.teco.domain.service;

public interface ConfigService {
    Object optimusLoginData();
}