package ir.tamin.teco.application.service;

import ir.tamin.teco.domain.repository.ConfigRepository;
import ir.tamin.teco.domain.service.ConfigService;
import ir.tamin.teco.shared.model.enums.ConfigKey;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class ConfigServiceImpl implements ConfigService {

    private final ConfigRepository configRepository;

    @Override
    public Object optimusLoginData() {


        String url =
                configRepository.getValue(
                        ConfigKey.OPTIMUS_URL) + "/auth/login"; //TODO

        String username =
                configRepository.getValue(
                        ConfigKey.OPTIMUS_USERNAME);

        String password =
                configRepository.getValue(
                        ConfigKey.OPTIMUS_PASSWORD);

        String applicationKey =
                configRepository.getValue(
                        ConfigKey.OPTIMUS_APPLICATION_KEY);

        String service =
                configRepository.getValue(
                        ConfigKey.OPTIMUS_SERVICE);

        //LoginModel

    }
}