package ir.tamin.teco.infrastructure.external.api;

import ir.tamin.teco.application.port.out.OptimusOut;

public class OptimusOutImpl implements OptimusOut {

}