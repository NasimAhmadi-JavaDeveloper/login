package ir.tamin.teco.application.service;

import ir.tamin.teco.domain.service.LoginService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LoginServiceImpl implements LoginService {

    @Override
    public Object login() { //TODO



    }

}
