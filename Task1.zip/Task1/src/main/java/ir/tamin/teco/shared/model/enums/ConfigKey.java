package ir.tamin.teco.shared.model.enums;

public enum ConfigKey {
    OPTIMUS_URL,
    OPTIMUS_USERNAME,
    OPTIMUS_PASSWORD,
    OPTIMUS_APPLICATION_KEY,
    OPTIMUS_SERVICE
}