package ir.tamin.teco.application.usecase.createcustomercredit;

import ir.tamin.teco.application.dto.CustomerCreditDto;
import ir.tamin.teco.application.mapper.CustomerCreditMapper;
import ir.tamin.teco.application.port.in.CreateCustomerCreditUseCase;
import ir.tamin.teco.domain.exception.BranchNotFoundException;
import ir.tamin.teco.domain.model.Branch;
import ir.tamin.teco.domain.model.CustomerCredit;
import ir.tamin.teco.domain.repository.BranchRepository;
import ir.tamin.teco.domain.repository.CustomerCreditRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CreateCustomerCreditHandler implements CreateCustomerCreditUseCase {

    private final BranchRepository branchRepository;
    private final CustomerCreditMapper customerCreditMapper;
    private final CustomerCreditRepository customerCreditRepository;

    @Override
    public CustomerCreditDto execute(CreateCustomerCreditCommand command) {

        Branch branch = getBranch(command.getUnitCode());

        CustomerCredit model = customerCreditMapper.toModel(command);

        model.setBranch(branch);

        CustomerCredit savedModel = customerCreditRepository.save(model);

        return customerCreditMapper.toDto(savedModel);
    }

    private Branch getBranch(String unitCode) {
        return branchRepository.findByCode(unitCode)
                .orElseThrow(() ->
                        new BranchNotFoundException(unitCode));//TODO
    }
}
