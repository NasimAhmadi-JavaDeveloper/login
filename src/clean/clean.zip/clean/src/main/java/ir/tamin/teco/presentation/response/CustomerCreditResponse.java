package ir.tamin.teco.presentation.response;

public class CustomerCreditResponse {
}
