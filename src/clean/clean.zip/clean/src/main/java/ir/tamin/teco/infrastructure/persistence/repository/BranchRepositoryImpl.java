package ir.tamin.teco.infrastructure.persistence.repository;

import ir.tamin.teco.domain.model.Branch;
import ir.tamin.teco.domain.repository.BranchRepository;
import ir.tamin.teco.infrastructure.persistence.mapper.BranchPersistenceMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class BranchRepositoryImpl implements BranchRepository {

    private final BranchPersistenceMapper mapper;
    private final JpaBranchRepository jpaRepository;

    @Override
    public Optional<Branch> findByCode(String code) {
        return jpaRepository.findByBrhCode(code).map(mapper::toDomain);
    }
}
