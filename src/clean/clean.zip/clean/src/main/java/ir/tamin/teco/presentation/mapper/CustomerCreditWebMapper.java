package ir.tamin.teco.presentation.mapper;

public interface CustomerCreditWebMapper {

}