package ir.tamin.teco.infrastructure.persistence.repository;

import ir.tamin.teco.domain.model.CustomerCredit;
import ir.tamin.teco.domain.repository.CustomerCreditRepository;
import ir.tamin.teco.infrastructure.persistence.entity.CustomerCreditEntity;
import ir.tamin.teco.infrastructure.persistence.mapper.CustomerCreditPersistenceMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class CustomerCreditRepositoryImpl implements CustomerCreditRepository {

    private final JpaCustomerCreditRepository jpaRepository;
    private final CustomerCreditPersistenceMapper mapper;

    @Override
    public CustomerCredit save(CustomerCredit domain) {

        CustomerCreditEntity entity = mapper.toEntity(domain);

        CustomerCreditEntity saved = jpaRepository.save(entity);

        return mapper.toDomain(saved);
    }

    @Override
    public Optional<CustomerCredit> findById(Long id) {
        return jpaRepository.findById(id).map(mapper::toDomain);
    }
}
