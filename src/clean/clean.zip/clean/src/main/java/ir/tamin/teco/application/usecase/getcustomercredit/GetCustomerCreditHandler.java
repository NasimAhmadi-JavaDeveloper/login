package ir.tamin.teco.application.usecase.getcustomercredit;

import ir.tamin.teco.application.dto.CustomerCreditDto;
import ir.tamin.teco.application.mapper.CustomerCreditMapper;
import ir.tamin.teco.application.port.in.GetCustomerCreditUseCase;
import ir.tamin.teco.domain.exception.CustomerCreditNotFoundException;
import ir.tamin.teco.domain.model.CustomerCredit;
import ir.tamin.teco.domain.repository.CustomerCreditRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class GetCustomerCreditHandler implements GetCustomerCreditUseCase {

    private final CustomerCreditMapper customerCreditMapper;
    private final CustomerCreditRepository customerCreditRepository;

    @Override
    public CustomerCreditDto execute(Long id) {
        CustomerCredit customerCredit =
                customerCreditRepository.findById(id)
                        .orElseThrow(() -> new CustomerCreditNotFoundException("not found"));//TODO

        return customerCreditMapper.toDto(customerCredit);
    }
}
