package ir.tamin.teco.presentation.advice;

public class GlobalExceptionHandler {
}
