package ir.tamin.teco.application.mapper;

import ir.tamin.teco.application.dto.CustomerCreditDto;
import ir.tamin.teco.application.usecase.createcustomercredit.CreateCustomerCreditCommand;
import ir.tamin.teco.domain.model.CustomerCredit;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CustomerCreditMapper {

    @Mapping(target = "branch", ignore = true)
    CustomerCredit toModel(CreateCustomerCreditCommand dto);

    CustomerCreditDto toDto(CustomerCredit model);

}