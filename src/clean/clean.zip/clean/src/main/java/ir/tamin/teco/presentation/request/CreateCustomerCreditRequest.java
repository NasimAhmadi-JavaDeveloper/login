package ir.tamin.teco.presentation.request;

public class CreateCustomerCreditRequest {

}