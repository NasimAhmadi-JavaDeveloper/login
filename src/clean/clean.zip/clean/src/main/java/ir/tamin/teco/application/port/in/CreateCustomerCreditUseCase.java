package ir.tamin.teco.application.port.in;

import ir.tamin.teco.application.dto.CustomerCreditDto;
import ir.tamin.teco.application.usecase.createcustomercredit.CreateCustomerCreditCommand;

public interface CreateCustomerCreditUseCase {

    CustomerCreditDto execute(CreateCustomerCreditCommand command);

}