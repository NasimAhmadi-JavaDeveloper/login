package ir.tamin.teco.presentation.controller;

import ir.tamin.teco.application.mapper.CustomerCreditMapper;
import ir.tamin.teco.application.port.in.CreateCustomerCreditUseCase;
import ir.tamin.teco.application.port.in.GetCustomerCreditUseCase;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/customer-credits")
public class CustomerCreditController {

    private final CreateCustomerCreditUseCase createUseCase;
    private final GetCustomerCreditUseCase getUseCase;
    private final CustomerCreditMapper mapper;


}
