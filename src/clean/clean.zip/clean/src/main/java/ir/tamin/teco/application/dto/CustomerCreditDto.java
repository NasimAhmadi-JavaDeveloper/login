package ir.tamin.teco.application.dto;

import lombok.*;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CustomerCreditDto { //TODO refactor fields

    private Long id;

    private String nationalCode;

    private String firstName;

    private String lastName;

    private Long amount;

    private String status;

}