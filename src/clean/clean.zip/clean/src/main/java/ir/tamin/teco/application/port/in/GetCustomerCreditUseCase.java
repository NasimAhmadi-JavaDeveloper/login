package ir.tamin.teco.application.port.in;

import ir.tamin.teco.application.dto.CustomerCreditDto;

public interface GetCustomerCreditUseCase {

    CustomerCreditDto execute(Long id);

}