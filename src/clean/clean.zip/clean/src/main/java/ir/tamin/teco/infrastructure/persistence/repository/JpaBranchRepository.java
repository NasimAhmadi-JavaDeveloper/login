package ir.tamin.teco.infrastructure.persistence.repository;

import ir.tamin.teco.infrastructure.persistence.entity.BranchEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface JpaBranchRepository extends JpaRepository<BranchEntity, String> {

    Optional<BranchEntity> findByBrhCode(String code);

}