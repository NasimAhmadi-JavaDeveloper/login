package ir.tamin.teco.application.result;

import lombok.*;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateCustomerCreditResult {

    private String s;

}