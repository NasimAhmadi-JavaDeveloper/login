package ir.tamin.teco.domain.service;

import ir.tamin.teco.domain.model.CustomerCredit;

public class CustomerCreditDomainService {

    public void validateForUpdate(CustomerCredit customerCredit) {
        //harch ke marbot be logic mishe, bedone spring hibernate import
    }
}
