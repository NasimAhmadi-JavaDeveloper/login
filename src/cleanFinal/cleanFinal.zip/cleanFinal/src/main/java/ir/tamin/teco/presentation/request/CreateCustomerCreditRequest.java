package ir.tamin.teco.presentation.request;

import lombok.*;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateCustomerCreditRequest {

    private String s;
}