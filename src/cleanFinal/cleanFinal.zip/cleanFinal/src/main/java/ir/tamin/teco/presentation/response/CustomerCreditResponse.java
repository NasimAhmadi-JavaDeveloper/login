package ir.tamin.teco.presentation.response;

import lombok.*;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CustomerCreditResponse {

    private String s;
}