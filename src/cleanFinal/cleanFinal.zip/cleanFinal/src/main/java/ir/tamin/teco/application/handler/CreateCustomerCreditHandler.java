package ir.tamin.teco.application.handler;

import ir.tamin.teco.application.mapper.CustomerCreditApplicationMapper;
import ir.tamin.teco.application.command.CreateCustomerCreditCommand;
import ir.tamin.teco.application.result.CreateCustomerCreditResult;
import ir.tamin.teco.application.usecase.CreateCustomerCreditUseCase;
import ir.tamin.teco.domain.exception.BranchNotFoundException;
import ir.tamin.teco.domain.model.Branch;
import ir.tamin.teco.domain.model.CustomerCredit;
import ir.tamin.teco.domain.repository.BranchRepository;
import ir.tamin.teco.domain.repository.CustomerCreditRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CreateCustomerCreditHandler implements CreateCustomerCreditUseCase {

    private final BranchRepository branchRepository;
    private final CustomerCreditApplicationMapper customerCreditApplicationMapper;
    private final CustomerCreditRepository customerCreditRepository;

    @Override
    public CreateCustomerCreditResult create(CreateCustomerCreditCommand command) {

        Branch branchModel = getBranch(command.getUnitCode());

        CustomerCredit model = customerCreditApplicationMapper.toModel(command);

        model.setBranch(branchModel);

        CustomerCredit savedModel = customerCreditRepository.save(model);

        return customerCreditApplicationMapper.toCreateResult(savedModel);
    }

    private Branch getBranch(String unitCode) {
        return branchRepository.findByCode(unitCode)
                .orElseThrow(() -> new BranchNotFoundException(unitCode));//TODO
    }
}
