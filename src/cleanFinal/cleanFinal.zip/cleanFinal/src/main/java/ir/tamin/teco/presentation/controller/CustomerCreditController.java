package ir.tamin.teco.presentation.controller;

import ir.tamin.teco.application.command.CreateCustomerCreditCommand;
import ir.tamin.teco.application.result.CreateCustomerCreditResult;
import ir.tamin.teco.application.usecase.CreateCustomerCreditUseCase;
import ir.tamin.teco.application.result.GetCustomerCreditResult;
import ir.tamin.teco.application.usecase.GetCustomerCreditUseCase;
import ir.tamin.teco.presentation.mapper.CustomerCreditWebMapper;
import ir.tamin.teco.presentation.request.CreateCustomerCreditRequest;
import ir.tamin.teco.presentation.response.CustomerCreditResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/customer-credits")
public class CustomerCreditController {

    private final CustomerCreditWebMapper webMapper;
    private final GetCustomerCreditUseCase getUseCase;
    private final CreateCustomerCreditUseCase createUseCase;

    @PostMapping
    public CustomerCreditResponse create(@RequestBody CreateCustomerCreditRequest request) {

        CreateCustomerCreditCommand command = webMapper.toCommand(request);

        CreateCustomerCreditResult result = createUseCase.create(command);

        return webMapper.toCreateResponse(result);
    }

    @GetMapping("/{id}")
    public CustomerCreditResponse getById(@PathVariable Long id) {

        GetCustomerCreditResult result = getUseCase.execute(id);

        return webMapper.toGetResponse(result);
    }
}
