package ir.tamin.teco.application.usecase;

import ir.tamin.teco.application.command.CreateCustomerCreditCommand;
import ir.tamin.teco.application.result.CreateCustomerCreditResult;

public interface CreateCustomerCreditUseCase {

    CreateCustomerCreditResult create(CreateCustomerCreditCommand command);

}