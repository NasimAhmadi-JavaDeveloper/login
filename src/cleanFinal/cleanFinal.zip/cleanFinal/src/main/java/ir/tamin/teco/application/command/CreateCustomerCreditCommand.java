package ir.tamin.teco.application.command;

import lombok.*;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateCustomerCreditCommand {

    private String personType;

    private String firstName;

    private String lastName;

    private String nationalCode;

    private String birthDate;

    private String fatherName;

    private String managerNationalCode;

    private String phone;

    private String unitCode;

    private String accountNo;

    private String debtReason;

    private Long amount;

    private Long discountAmount;

}