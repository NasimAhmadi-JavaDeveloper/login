package ir.tamin.teco.presentation.mapper;

import ir.tamin.teco.application.command.CreateCustomerCreditCommand;
import ir.tamin.teco.application.result.CreateCustomerCreditResult;
import ir.tamin.teco.application.result.GetCustomerCreditResult;
import ir.tamin.teco.presentation.request.CreateCustomerCreditRequest;
import ir.tamin.teco.presentation.response.CustomerCreditResponse;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CustomerCreditWebMapper {

    CreateCustomerCreditCommand toCommand(CreateCustomerCreditRequest request);

    CustomerCreditResponse toCreateResponse(CreateCustomerCreditResult result);

    CustomerCreditResponse toGetResponse(GetCustomerCreditResult result);

}