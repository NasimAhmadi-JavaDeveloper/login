package ir.tamin.teco.application.mapper;

import ir.tamin.teco.application.command.CreateCustomerCreditCommand;
import ir.tamin.teco.application.result.CreateCustomerCreditResult;
import ir.tamin.teco.application.result.GetCustomerCreditResult;
import ir.tamin.teco.domain.model.CustomerCredit;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CustomerCreditApplicationMapper {

    @Mapping(target = "branch", ignore = true)
    CustomerCredit toModel(CreateCustomerCreditCommand command);

    CreateCustomerCreditResult toCreateResult(CustomerCredit model);

    GetCustomerCreditResult toGetResult(CustomerCredit model);

}