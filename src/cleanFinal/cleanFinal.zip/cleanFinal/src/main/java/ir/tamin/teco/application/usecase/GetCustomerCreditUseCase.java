package ir.tamin.teco.application.usecase;

import ir.tamin.teco.application.result.GetCustomerCreditResult;

public interface GetCustomerCreditUseCase {

    GetCustomerCreditResult execute(Long id);

}